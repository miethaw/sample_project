import React from 'react';

const App=()=> {
  
  return (
    <div className="App">
      
      <SideBar />
    </div>
  );
}

export default App;
