import React, { useState } from 'react';
import logo from './logo.svg';
import './App.css';
import SideBar from './components/sideBar';
import MissingSensors from './components/MissingSensors'
import AssetsList from './components/AssetsList'
import SensorStatus from './components/SensorStatus'
import VendorInformation from './components/VendorInformation'


const App = () => {
  const [sidebarOpen, setSideBarOpen] = useState(true)


  return (
    <div className="">

      <SideBar sidebarOpen={sidebarOpen} setSideBarOpen={setSideBarOpen} site={"President Bakery"} />
      <div className='pt-4' style={{ paddingLeft: sidebarOpen ? 80 : 270 }}>
        <div className='d-flex flex-md-wrap flex-sm-wrap p-0 m-1' style={{ borderBottom: '1px solid gray' }}>
          <div className='col-xl-4 col-lg-4 flex-fill m-2' style={{  minWidth: 300 }}>
            <MissingSensors />
          </div>
          <div className='col-xl-8 col-lg-8 flex-fill m-2' style={{ minWidth: 500 }}>
            <AssetsList />
          </div>

        </div>
        <div className='d-flex py-2 flex-md-wrap flex-sm-wrap flex-lg-wrap m-1'>
          <div className='col-6 flex-fill m-2' style={{ }}>
            <SensorStatus />
          </div>
          <div className='col-6 flex-fill m-2' style={{ minWidth: 350 }}>
            <VendorInformation />
          </div>
        </div>

      </div>

    </div>
  );
}

export default App;
